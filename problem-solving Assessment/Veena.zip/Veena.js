"use strict"
// --------------------1 sum--------------------------------------
// let a=[ 3, 7, 2, 1, 7, 9,10,12,22,13 ]
// var v;
// let c;
// for(let i=0;i<a.length;i++){
    
//     if(a[i]%2==0){
//     v = a[i]    
//     var b=Math.max(v)
    
//     }

// }
// console.log(b)


// -----------------4 sum-----------------------------------------
// let a = [1,5,3,5]
// let y;
// for (let i = 1; i < a.length; i++) {
//     for (let j = 1; j < a.length; j++) {

//         if (a[i] == a[j]) {
//             y = a[i]
//         }
       
//     }

// }
// console.log(y);
// ----------------------------------------------------------------------------
// let a=prompt("Enter a sentence")

// let a=("enter a sentence")
// let b=a.split(" ")
// let c;
// console.log(b)
// for(let i=0;i<b.length;i++){
//        if(a.charAt(i%2 ==0)){
//         c =b[i].toLowerCase()
//        }
//        else {
//         c = b[i].toUpperCase()
//        }
      
// }
// console.log(c)


// ------------------------set -b-------------------------------------------------------------------
// // ------------------------------2 sum-------------------------------------------
// for (let i = 2; i <20; i++) {
//     let b = true;
  
//     for (let j = 2; j < i; j++) {
//       if (i % j === 0) {
//         b= false;
//       }
//     }
  
//     if (b) {
//       console.log(i);
//     }
//   }
//   -------------------------------------------------------------